# 产品源码快照

2026-10-07本地源码，不含真实data/private、环境实际值、数据库、课表、邮箱、照片、消息、定位、node_modules或.next。仅含显式.seed.json示例；依赖与OCR/PDF资源由npm ci/postinstall准备。需要Node.js 24和自行配置的隔离开发环境。未在本次打包后重新执行技术测试；2026-10-06验收是历史基线。正式维护入口仍为主仓库xjtlu-market-app，本快照不会自动同步。
