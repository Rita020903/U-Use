# 产品源码快照

2026-10-07本地源码，不含真实data/private、环境实际值、数据库、课表、邮箱、照片、消息、定位、node_modules或.next。仅含显式.seed.json示例；依赖与OCR/PDF资源由npm ci/postinstall准备。需要Node.js 24和自行配置的隔离开发环境。产品代码已在2026-10-07通过GitHub CI（含PostgreSQL）；这是测试记录，不是正式上线验收。测试版本和链接见快照内README，快照不含实时CI状态。正式维护入口仍为主仓库xjtlu-market-app，本快照不会自动同步。
